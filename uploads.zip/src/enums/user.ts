/* eslint-disable no-unused-vars */
export enum ENUM_USER_ROLE {
  ADMIN = 'admin',
  USER = 'user',
}
