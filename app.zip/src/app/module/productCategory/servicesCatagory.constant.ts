export const customerSearchableFields = [
  'searchTerm',
  'name',
  'phone',
  'email',
];

export const customerFilterableFields = ['name', 'phone', 'email'];
