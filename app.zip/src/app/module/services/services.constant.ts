export const customerSearchableFields = [
  'searchTerm',
  'name',
  'phone',
  'email',
  'servicesCatagory',
];

export const customerFilterableFields = [
  'name',
  'phone',
  'email',
  'servicesCatagory',
];
