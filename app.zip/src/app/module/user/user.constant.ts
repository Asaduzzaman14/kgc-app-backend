export const donnorSearchableFields = ['searchTerm', 'name', 'phone', 'email'];

export const donnoeFilterableFields = [
  'name',
  'phone',
  'email',
  'bloodGroup',
  'isDonor',
];
